package com.mercadona.shopone;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MercadonaShopOneTest {

    @Test
    void item_generico_no_caducado() {
        Item[] items = new Item[] { new Item("Generico", 3, 12) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Generico", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(11, app.items[0].quality);
    }

    @Test
    void item_generico_caducado() {
        Item[] items = new Item[] { new Item("Generico", 0, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Generico", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(8, app.items[0].quality);
    }

    @Test
    void item_generico_minima_calidad() {
        Item[] items = new Item[] { new Item("Generico", 3, 0) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Generico", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }

    @Test
    void item_Ham_no_caducado() {
        Item[] items = new Item[] { new Item("Ham", 20, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(19, app.items[0].sellIn);
        assertEquals(11, app.items[0].quality);
    }

    @Test
    void item_Ham_faltan_menos_diez_dias() {
        Item[] items = new Item[] { new Item("Ham", 7, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(6, app.items[0].sellIn);
        assertEquals(12, app.items[0].quality);
    }

    @Test
    void item_Ham_faltan_menos_cinco_dias() {
        Item[] items = new Item[] { new Item("Ham", 4, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(3, app.items[0].sellIn);
        assertEquals(13, app.items[0].quality);
    }

    @Test
    void item_Ham_caducado() {
        Item[] items = new Item[] { new Item("Ham", -1, 0) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(-2, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }

    @Test
    void item_Ham_maxima_calidad() {
        Item[] items = new Item[] { new Item("Ham", 6, 50) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(5, app.items[0].sellIn);
        assertEquals(50, app.items[0].quality);
    }

    @Test
    void item_blueCheese_no_caducado() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 5, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(4, app.items[0].sellIn);
        assertEquals(11, app.items[0].quality);
    }

    @Test
    void item_blueCheese_caducado() {
        Item[] items = new Item[] { new Item("Aged blue cheese",-1, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(-2, app.items[0].sellIn);
        assertEquals(12, app.items[0].quality);
    }

    @Test
    void item_blueCheese_maxima_calidad() {
        Item[] items = new Item[] { new Item("Aged blue cheese",7, 50) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(6, app.items[0].sellIn);
        assertEquals(50, app.items[0].quality);
    }

    @Test
    void item_IodizedSalt_no_se_modifica() {
        Item[] items = new Item[] { new Item("Iodized salt",7, 80) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Iodized salt", app.items[0].name);
        assertEquals(7, app.items[0].sellIn);
        assertEquals(80, app.items[0].quality);
    }

    @Test
    void item_congelado_no_caducado() {
        Item[] items = new Item[] { new Item("Frozen cake", 3, 12) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(10, app.items[0].quality);
    }

    @Test
    void item_congelado_caducado() {
        Item[] items = new Item[] { new Item("Frozen cake", -1, 12) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(-2, app.items[0].sellIn);
        assertEquals(8, app.items[0].quality);
    }

    @Test
    void item_congelado_minima_calidad_cadudcado() {
        Item[] items = new Item[] { new Item("Frozen cake", -6, 0) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(-7, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }

    @Test
    void item_congelado_minima_calidad_no_caducado() {
        Item[] items = new Item[] { new Item("Frozen cake", 3, 0) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }

}
