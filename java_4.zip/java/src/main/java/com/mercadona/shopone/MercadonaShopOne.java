package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] items;

    public MercadonaShopOne(Item[] items) {
        this.items = items;
    }

    public void incrementQuality(Item item, int cantidad) {

        if ((item.quality + cantidad) >= 50) {
            item.quality = 50;
        } else {
            item.quality += cantidad;
        }
    }

    public void decrementQuality(Item item, int cantidad) {

        if ((item.quality - cantidad) <= 0) {
            item.quality = 0;
        } else {
            item.quality -= cantidad;
        }

    }

    public void updateQuality() {

        boolean isExpired;

        for (Item item : items) {

            isExpired = item.sellIn <= 0;

            if (item.name.equals("Aged blue cheese")) {

                if (isExpired) {

                    incrementQuality(item, 2);

                } else {

                    incrementQuality(item, 1);
                }

            } else if (item.name.equals("Ham")) {

                if (isExpired) {

                    item.quality = 0;

                } else {

                    if (item.sellIn < 10 && item.sellIn > 5) {

                        incrementQuality(item, 2);

                    } else if (item.sellIn < 5 && item.sellIn > 0) {

                        incrementQuality(item, 3);

                    } else {

                        incrementQuality(item, 1);

                    }
                }

            } else if (!item.name.equals("Iodized salt")) {

                if (isExpired) {

                    if (item.name.equals("Frozen cake")) {

                        decrementQuality(item, 4);

                    } else {

                        decrementQuality(item, 2);

                    }

                } else {

                    if (item.name.equals("Frozen cake")) {

                        decrementQuality(item, 2);
                    } else {

                        decrementQuality(item, 1);
                    }

                }

            }

            if (!item.name.equals("Iodized salt")) {

                item.sellIn -= 1;

            }
        }
    }
}