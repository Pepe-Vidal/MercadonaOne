package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] items;

    public MercadonaShopOne(Item[] items) {
        this.items = items;
    }

    public void modifyQuality(Item item, int cantidad) {

        int newQuality = item.quality + cantidad;

        if (newQuality >= 0 && newQuality <= 50) {

            item.quality = newQuality;

        } else if (newQuality < 0) {

            item.quality = 0;

        } else {

            item.quality = 50;

        }

    }

    public void updateQuality() {

        boolean isExpired;

        for (Item item : items) {

            if (item.name.equals("Iodized salt")) {
                break;
            }

            isExpired = item.sellIn <= 0;

            if (item.name.equals("Aged blue cheese")) {

                if (isExpired) {

                    modifyQuality(item, 2);

                } else {

                    modifyQuality(item, 1);
                }

            } else if (item.name.equals("Ham")) {

                if (isExpired) {

                    item.quality = 0;

                } else {

                    if (item.sellIn < 10 && item.sellIn > 5) {

                        modifyQuality(item, 2);

                    } else if (item.sellIn < 5 && item.sellIn > 0) {

                        modifyQuality(item, 3);

                    } else {

                        modifyQuality(item, 1);

                    }
                }

            } else if (item.name.equals("Frozen cake")) {

                if (isExpired) {

                    modifyQuality(item, -4);

                } else {

                    modifyQuality(item, -2);
                }

            } else {

                if (isExpired) {

                    modifyQuality(item, -2);

                } else {

                    modifyQuality(item, -1);

                }

            }

            item.sellIn -= 1;

        }
    }
}